package org.runner.pckg;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = "./src/test/java/org/feature/pckg", glue = { "classpath:org.stepdef.pckg" }, format = {
		"pretty", "html:target/Cucumber" }, monochrome = true)

public class RunnerTest {

}
