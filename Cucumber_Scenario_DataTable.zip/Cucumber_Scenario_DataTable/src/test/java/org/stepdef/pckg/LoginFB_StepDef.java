package org.stepdef.pckg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginFB_StepDef 
{
	static WebDriver wd=null;
	@Given("^user opens \"([^\"]*)\" and opens \"([^\"]*)\"$")
	public void openbrowser(String bname,String url) {
		
		if (bname.equalsIgnoreCase("Firefox")) {
			System.out.println("Initialising " + bname + " driver");
			System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "\\geckodriver.exe");
			DesiredCapabilities capabilities = DesiredCapabilities.firefox();
			capabilities.setCapability("marionette", true);
			wd = new FirefoxDriver(capabilities);
			wd.get(url);
		}
		if (bname.equalsIgnoreCase("IE")) {
			System.out.println("Initialising " + bname + " driver");
			System.setProperty("webdriver.ie.driver", System.getProperty("user.dir") + "\\IEDriverServer.exe");
			DesiredCapabilities dc = DesiredCapabilities.internetExplorer();
			dc.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
			wd = new InternetExplorerDriver(dc);
			wd.get(url);
		}
		if (bname.equalsIgnoreCase("Chrome")) {
			System.out.println("Initialising " + bname + " driver");
			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "\\chromedriver.exe");
			wd = new ChromeDriver();
			wd.get(url);
		}
}

	@When("^user enters \"([^\"]*)\" and \"([^\"]*)\"$")
	public void filluserdetails(String uname,String pwd) 
	{
		wd.findElement(By.xpath(".//*[@id='email']")).sendKeys(uname);
		wd.findElement(By.xpath(".//*[@id='pass']")).sendKeys(pwd);
	}

	@When("^user clicks on login button$")
	public void selectlogin() throws Exception 
	{
		wd.findElement(By.xpath(".//*[@id='loginbutton']")).click();
		Thread.sleep(5000);
	}

	@Then("^user successfully logged in$")
	public void user_successfully_logged_in() throws Throwable 
	{
		wd.quit();
	}
}