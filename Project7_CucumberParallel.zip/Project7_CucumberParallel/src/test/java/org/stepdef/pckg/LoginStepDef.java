package org.stepdef.pckg;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDef
{
	static WebDriver wd;
	@When("^user opens browser \"([^\"]*)\"$")
	public void user_opens_browser(String arg1)
	{
		System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "\\geckodriver.exe");
		DesiredCapabilities capabilities = DesiredCapabilities.firefox();
		capabilities.setCapability("marionette", true);
		wd = new FirefoxDriver(capabilities);
		wd.get(arg1);
	}
	@Then("^user enter search text as \"([^\"]*)\"$")
	public void user_enter_search_text_as(String arg1)
	{
		System.out.println("User enters text as:--"+arg1);
	}
	@Then("^click on Search button$")
	public void click_on_Search_button()
	{
		System.out.println("user clickson search button");
	}
}
